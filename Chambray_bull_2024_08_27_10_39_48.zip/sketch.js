let paddleWidth = 10;
let paddleHeight = 80;
let paddleSpeed = 5;
let paddle1Y;
let paddle2Y;
let paddle1Score = 0;
let paddle2Score = 0;

let ball;
let ballSize = 10;
let ballSpeedX = 3;
let ballSpeedY = 3;

function setup() {
  createCanvas(400, 400);
  paddle1Y = height / 2 - paddleHeight / 2;
  paddle2Y = height / 2 - paddleHeight / 2;
  ball = createVector(width / 2, height / 2);
}

function draw() {
  background(0);
  
  // Desenha os paddles
  fill(255);
  rect(0, paddle1Y, paddleWidth, paddleHeight);
  rect(width - paddleWidth, paddle2Y, paddleWidth, paddleHeight);
  
  // Movimenta os paddles
  if (keyIsDown(UP_ARROW)) {
    paddle2Y -= paddleSpeed;
  } else if (keyIsDown(DOWN_ARROW)) {
    paddle2Y += paddleSpeed;
  }
  
  if (keyIsDown(87)) { // W key
    paddle1Y -= paddleSpeed;
  } else if (keyIsDown(83)) { // S key
    paddle1Y += paddleSpeed;
  }
  
  // Mantém os paddles dentro dos limites da tela
  paddle1Y = constrain(paddle1Y, 0, height - paddleHeight);
  paddle2Y = constrain(paddle2Y, 0, height - paddleHeight);
  
  // Movimenta a bola
  ball.x += ballSpeedX;
  ball.y += ballSpeedY;
  
  // Verifica as colisões com os paddles
  if (
    (ballSpeedX > 0 && ball.x + ballSize / 2 >= width - paddleWidth && ball.y + ballSize / 2 >= paddle2Y && ball.y - ballSize / 2 <= paddle2Y + paddleHeight) ||
    (ballSpeedX < 0 && ball.x - ballSize / 2 <= paddleWidth && ball.y + ballSize / 2 >= paddle1Y && ball.y - ballSize / 2 <= paddle1Y + paddleHeight)
  ) {
    ballSpeedX *= -1;
  }
  
  // Verifica as colisões com as paredes superior e inferior
  if (ball.y + ballSize / 2 >= height || ball.y - ballSize / 2 <= 0) {
    ballSpeedY *= -1;
  }
  
  // Verifica se a bola saiu da tela
  if (ball.x + ballSize / 2 >= width) {
    paddle1Score++;
    resetBall();
  } else if (ball.x - ballSize / 2 <= 0) {
    paddle2Score++;
    resetBall();
  }
  
  // Desenha a bola
  fill(255);
  ellipse(ball.x, ball.y, ballSize);
  
  // Desenha os placares
  textSize(24);
  text(paddle1Score, width / 4, 30);
  text(paddle2Score, width * 3 / 4, 30);
}

function resetBall() {
  ball = createVector(width / 2, height / 2);
  ballSpeedX *= random([-1, 1]);
  ballSpeedY *= random([-1, 1]);
}
